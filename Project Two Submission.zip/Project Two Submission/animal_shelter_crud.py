from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter:
    """ CRUD operations for the Animal collection in MongoDB """

    def __init__(self, username, password):
        USER = 'aacuser'
        PASS = '<elpatron1m'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32518
        DB = 'AAC'
        COL = 'animals'

        # Initialize MongoDB connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/?authSource=admin')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Insert a document into the database"""
        if data:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
            raise ValueError("Data parameter is empty")

    def read(self, query):
        """Retrieve documents from the database based on a query"""
        if query is not None:
            results = self.collection.find(query)
            return list(results)
        else:
            raise ValueError("Query parameter is empty")

    def update(self, query, new_values):
        """Update document(s) in the database"""
        if query and new_values:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        else:
            raise ValueError("Query or new_values parameter is empty")

    def delete(self, query):
        """Delete document(s) from the database"""
        if query:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise ValueError("Query parameter is empty")